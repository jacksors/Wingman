create function numeric_pl_pg_lsn(numeric, pg_lsn) returns pg_lsn
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN ($2 + $1);

comment on function numeric_pl_pg_lsn(numeric, pg_lsn) is 'implementation of + operator';

alter function numeric_pl_pg_lsn(numeric, pg_lsn) owner to postgres;

